package com.cermsp.cermsp.filter;

import com.cermsp.cermsp.config.properties.JwtProperties;
import com.cermsp.cermsp.entity.User;
import com.cermsp.cermsp.service.UserService;
import com.cermsp.cermsp.util.JwtUtil;
import org.springframework.http.HttpMethod;
import org.springframework.lang.NonNull;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.web.authentication.WebAuthenticationDetailsSource;
import org.springframework.security.web.util.matcher.AntPathRequestMatcher;
import org.springframework.stereotype.Component;
import org.springframework.web.filter.OncePerRequestFilter;

import javax.servlet.FilterChain;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;

/**
 * jwt access_token 拦截器，用户拦截 token 并认证
 */
@Component
public class AccessTokenAuthenticationFilter extends OncePerRequestFilter {

    private final JwtProperties jwtProperties;
    private final UserService userService;

    public AccessTokenAuthenticationFilter(JwtProperties jwtProperties, UserService userService) {
        this.jwtProperties = jwtProperties;
        this.userService = userService;
    }

    @Override
    protected void doFilterInternal(@NonNull HttpServletRequest request, @NonNull HttpServletResponse response, @NonNull FilterChain filterChain) throws ServletException, IOException {
        // 跳过刷新 token 的请求
        AntPathRequestMatcher requestMatcher = new AntPathRequestMatcher("/api/v1/authentication", HttpMethod.PUT.toString());
        if (requestMatcher.matches(request)) {
            filterChain.doFilter(request, response);
            return;
        }

        JwtUtil jwtUtil = new JwtUtil(jwtProperties);

        // 如果已经通过认证 或 没有 token
        if (SecurityContextHolder.getContext().getAuthentication() != null || !jwtUtil.hasToken(request)) {
            filterChain.doFilter(request, response);
            return;
        }
        String token = jwtUtil.resolveToken(request);

        jwtUtil.validateAccessToken(token);
        User user = (User) userService.loadUserByUsername(jwtUtil.getUsername(token));
        UsernamePasswordAuthenticationToken usernamePasswordAuthenticationToken = new UsernamePasswordAuthenticationToken(user, null, user.getAuthorities());
        usernamePasswordAuthenticationToken.setDetails(new WebAuthenticationDetailsSource().buildDetails(request));
        // 放入安全上下文中
        SecurityContextHolder.getContext().setAuthentication(usernamePasswordAuthenticationToken);
        filterChain.doFilter(request, response);
    }
}
