package com.cermsp.cermsp.filter;

import com.cermsp.cermsp.util.ResponseUtil;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.AuthenticationException;
import org.springframework.security.web.authentication.UsernamePasswordAuthenticationFilter;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.util.Map;

public class LoginFilter extends UsernamePasswordAuthenticationFilter {

    public LoginFilter() {
        // 自定义认证错误处理方式，将错误抛出由 EntryPoint 处理
        setAuthenticationFailureHandler((request1, response1, exception) -> {
            throw exception;
        });
    }

    @Override
    public Authentication attemptAuthentication(HttpServletRequest request, HttpServletResponse response) throws AuthenticationException {
        Map<?, ?> body = ResponseUtil.getJsonBody(request);
        String username = (String) body.get("username");
        username = username != null ? username : "";
        username = username.trim();
        String password = (String) body.get("password");
        password = password != null ? password : "";
        UsernamePasswordAuthenticationToken authRequest = new UsernamePasswordAuthenticationToken(username, password);
        this.setDetails(request, authRequest);
        return this.getAuthenticationManager().authenticate(authRequest);
    }
}
