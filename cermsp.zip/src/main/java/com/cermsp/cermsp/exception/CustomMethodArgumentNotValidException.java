package com.cermsp.cermsp.exception;

public class CustomMethodArgumentNotValidException extends RuntimeException {

    public CustomMethodArgumentNotValidException(String message) {
    }
}
