package com.cermsp.cermsp.exception;

public class RefreshTokenExpiredException extends RuntimeException {
}
