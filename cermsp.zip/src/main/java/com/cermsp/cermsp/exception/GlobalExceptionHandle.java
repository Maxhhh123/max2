package com.cermsp.cermsp.exception;

import com.cermsp.cermsp.entity.Exception;
import com.cermsp.cermsp.resource.ExceptionResource;
import com.cermsp.cermsp.resource.JsonResource;
import com.cermsp.cermsp.util.enumation.ResponseCodeEnum;
import io.jsonwebtoken.MalformedJwtException;
import org.springframework.core.env.Environment;
import org.springframework.http.HttpStatus;
import org.springframework.security.authentication.BadCredentialsException;
import org.springframework.security.authentication.InsufficientAuthenticationException;
import org.springframework.security.core.AuthenticationException;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.util.CollectionUtils;
import org.springframework.validation.BindException;
import org.springframework.validation.BindingResult;
import org.springframework.validation.FieldError;
import org.springframework.web.HttpRequestMethodNotSupportedException;
import org.springframework.web.bind.MethodArgumentNotValidException;
import org.springframework.web.bind.MissingServletRequestParameterException;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestControllerAdvice;
import org.springframework.web.servlet.NoHandlerFoundException;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

@RestControllerAdvice
public class GlobalExceptionHandle {

    private final Environment environment;

    public GlobalExceptionHandle(Environment environment) {
        this.environment = environment;
    }

    /**
     * 处理 json 请求体调用接口对象参数校验失败抛出的异常
     */
    @ResponseStatus(HttpStatus.BAD_REQUEST)
    @ExceptionHandler(MethodArgumentNotValidException.class)
    public Map<String, Object> jsonParamsExceptionHandle(MethodArgumentNotValidException e) {

        BindingResult bindingResult = e.getBindingResult();

        ArrayList<String> errorList = new ArrayList<>();

        for (FieldError fieldError : bindingResult.getFieldErrors()) {
            String msg = String.format("%s%s；", fieldError.getField(), fieldError.getDefaultMessage());
            errorList.add(msg);
        }

        JsonResource<Exception> resource = new ExceptionResource().setMessages(errorList);
        if (!CollectionUtils.isEmpty(bindingResult.getFieldErrors())) {
            switch (bindingResult.getFieldErrors().get(0).getField()) {
                case "username" -> resource.setResponseCode(ResponseCodeEnum.BAD_REQUEST_USERNAME_REPEAT);
                case "telephone" -> resource.setResponseCode(ResponseCodeEnum.BAD_REQUEST_TELEPHONE_REPEAT);
            }
        }

        return resource.toResponse();
    }

    @ResponseStatus(HttpStatus.BAD_REQUEST)
    @ExceptionHandler(MissingServletRequestParameterException.class)
    public Map<String, Object> missingServletRequestParameterExceptionHandle(MissingServletRequestParameterException e) {
        return new ExceptionResource()
                .setMessage(e.getParameterName() + " 不能为空")
                .setResponseCode(ResponseCodeEnum.BAD_REQUEST_BIND_EXCEPTION)
                .toResponse();
    }

    /**
     * 处理自定义的接口参数校验失败抛出的异常
     */
    @ResponseStatus(HttpStatus.BAD_REQUEST)
    @ExceptionHandler(CustomMethodArgumentNotValidException.class)
    public Map<String, Object> jsonParamsExceptionHandle(CustomMethodArgumentNotValidException e) {
        return new ExceptionResource()
                .setMessage(e.getMessage())
                .setResponseCode(ResponseCodeEnum.BAD_REQUEST_BIND_EXCEPTION)
                .toResponse();
    }

    /**
     * Token 格式异常
     */
    @ResponseStatus(HttpStatus.UNAUTHORIZED)
    @ExceptionHandler(MalformedJwtException.class)
    public Map<String, Object> malformedJwtExceptionHandle(MalformedJwtException e) {
        return new ExceptionResource()
                .setResponseCode(ResponseCodeEnum.UNAUTHORIZED_MALFORMED_JWT)
                .toResponse();
    }

    /**
     * accessToken 过期
     */
    @ResponseStatus(HttpStatus.UNAUTHORIZED)
    @ExceptionHandler(AccessTokenExpiredException.class)
    public Map<String, Object> accessTokenExpiredExceptionHandle(AccessTokenExpiredException e) {
        return new ExceptionResource()
                .setResponseCode(ResponseCodeEnum.UNAUTHORIZED_ACCESS_TOKEN_EXPIRED)
                .toResponse();
    }

    /**
     * refreshToken 过期
     */
    @ResponseStatus(HttpStatus.UNAUTHORIZED)
    @ExceptionHandler(RefreshTokenExpiredException.class)
    public Map<String, Object> refreshTokenExpiredExceptionHandle(RefreshTokenExpiredException e) {
        return new ExceptionResource()
                .setResponseCode(ResponseCodeEnum.UNAUTHORIZED_REFRESH_TOKEN_EXPIRED)
                .toResponse();
    }

    @ResponseStatus(HttpStatus.UNAUTHORIZED)
    @ExceptionHandler(UsernameNotFoundException.class)
    public Map<String, Object> usernameNotFoundExceptionHandle(UsernameNotFoundException e) {
        return new ExceptionResource()
                .setResponseCode(ResponseCodeEnum.UNAUTHORIZED_USERNAME_NOT_FOUND)
                .toResponse();
    }

    /**
     * 登录凭证有误
     */
    @ResponseStatus(HttpStatus.UNAUTHORIZED)
    @ExceptionHandler(BadCredentialsException.class)
    public Map<String, Object> badCredentialsExceptionExceptionHandle(BadCredentialsException e) {
        return new ExceptionResource()
                .setResponseCode(ResponseCodeEnum.UNAUTHORIZED_BAD_CREDENTIALS)
                .toResponse();
    }

    /**
     * 访问不存在的接口（但没有通过用户验证）
     */
    @ResponseStatus(HttpStatus.UNAUTHORIZED)
    @ExceptionHandler(InsufficientAuthenticationException.class)
    public Map<String, Object> insufficientAuthenticationExceptionHandle(InsufficientAuthenticationException e) {
        return new ExceptionResource()
                .setResponseCode(ResponseCodeEnum.UNAUTHORIZED)
                .toResponse();
    }


    @ResponseStatus(HttpStatus.UNAUTHORIZED)
    @ExceptionHandler(AuthenticationException.class)
    public Map<String, Object> authenticationExceptionHandle(AuthenticationException e) {
        return new ExceptionResource()
                .setResponseCode(ResponseCodeEnum.UNAUTHORIZED)
                .setMessage(e.getLocalizedMessage())
                .toResponse();
    }

//    /**
//     * 处理单个参数校验失败抛出的异常
//     */
//    @ResponseStatus(HttpStatus.BAD_REQUEST)
//    @ExceptionHandler(ConstraintViolationException.class)
//    public Map<String, Object> ConstraintViolationExceptionHandle(ConstraintViolationException e) {
//
//
//        List errorList = CollectionUtil.newArrayList();
//
//        Set<ConstraintViolation<?>> violations = e.getConstraintViolations();
//
//        for (ConstraintViolation<?> violation : violations) {
//
//            StringBuilder message = new StringBuilder();
//
//            Path path = violation.getPropertyPath();
//
//            String[] pathArr = StrUtil.splitToArray(path.toString(), ".");
//
//            String msg = message.append(pathArr[1]).append(violation.getMessage()).toString();
//
//            errorList.add(msg);
//
//        }
//
//        return `Result`Response.failure(ResultCode.PARAMS_IS_INVALID, errorList);
//
//    }


    /**
     * @return 处理 GET 方式调用接口对象参数校验失败抛出的异常
     */
    @ResponseStatus(HttpStatus.BAD_REQUEST)
    @ExceptionHandler(BindException.class)
    public Map<String, Object> formDaraParamsException(BindException e) {

        List<FieldError> fieldErrors = e.getBindingResult().getFieldErrors();
        List<String> messages = fieldErrors.stream()
                .map(o -> o.getField() + o.getDefaultMessage()).toList();

        return new ExceptionResource()
                .setResponseCode(ResponseCodeEnum.BAD_REQUEST_BIND_EXCEPTION)
                .setMessages(messages)
                .toResponse();

    }


    /**
     * 请求方法不被允许异常
     */
    @ResponseStatus(HttpStatus.METHOD_NOT_ALLOWED)
    @ExceptionHandler(HttpRequestMethodNotSupportedException.class)
    public Map<String, Object> httpRequestMethodNotSupportedException(HttpRequestMethodNotSupportedException e) {

        return new ExceptionResource()
                .setResponseCode(ResponseCodeEnum.METHOD_NOT_ALLOWED)
                .setMessage(environment.getProperty("error-message.method-not-supported"))
                .toResponse();
    }


//    /**
//     * @param e
//     * @return Content-Type/Accept 异常
//     * <p>
//     * application/json
//     * <p>
//     * application/x-www-form-urlencoded
//     */
//    @ExceptionHandler(HttpMediaTypeNotSupportedException.class)
//
//    public Result httpMediaTypeNotSupportedException(HttpMediaTypeNotSupportedException e) {
//
//        return ResultResponse.failure(ResultCode.BAD_REQUEST);
//
//    }


    /**
     * 接口不存在的异常
     */
    @ResponseStatus(HttpStatus.NOT_FOUND)
    @ExceptionHandler(NoHandlerFoundException.class)
    public Map<String, Object> noHandlerFoundExceptionHandle(NoHandlerFoundException e) {
        return new ExceptionResource()
                .setResponseCode(ResponseCodeEnum.NOT_FOUND)
                .setMessage(environment.getProperty("error-message.not-found"))
                .toResponse();
    }

    /**
     * 未知异常
     */
    @ResponseStatus(HttpStatus.BAD_REQUEST)
    @ExceptionHandler(java.lang.Exception.class)
    public Map<String, Object> UnNoException(Exception e) {
        return new ExceptionResource()
                .setResponseCode(ResponseCodeEnum.INTERNAL_SERVER_ERROR)
                .setMessage("未知错误").toResponse();
    }
}
