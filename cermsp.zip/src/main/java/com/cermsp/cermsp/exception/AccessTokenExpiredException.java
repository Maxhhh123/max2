package com.cermsp.cermsp.exception;

public class AccessTokenExpiredException extends RuntimeException {
}
