package com.cermsp.cermsp.request.validator;

import com.cermsp.cermsp.repository.BaseRepository;

import javax.validation.Constraint;
import javax.validation.Payload;
import java.lang.annotation.ElementType;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;

@Target({ElementType.FIELD, ElementType.TYPE})
@Retention(RetentionPolicy.RUNTIME)
@Constraint(validatedBy = {UniqueValidator.class}) // 标明由哪个类执行校验逻辑
public @interface Unique {

    // 实体
    Class<? extends BaseRepository<?>> repository();

    // 字段
    String field();

    String message() default "字段重复";

    Class<?>[] groups() default {};

    Class<? extends Payload>[] payload() default {};
}
