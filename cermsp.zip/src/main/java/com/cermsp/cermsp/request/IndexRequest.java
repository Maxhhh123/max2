package com.cermsp.cermsp.request;

import lombok.Data;

import javax.validation.constraints.NotNull;

@Data
public class IndexRequest {

    @NotNull(groups = FindIndex.class)
    private Integer isParent;
    private Integer parentId;

    public interface FindIndex {
    }
}
