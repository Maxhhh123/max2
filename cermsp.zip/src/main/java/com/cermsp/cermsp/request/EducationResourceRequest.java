package com.cermsp.cermsp.request;

import lombok.Data;

@Data
public class EducationResourceRequest {

//    @NotNull(groups = FindEducationResource.class)
//    private List<Integer> regionCodes;
//
//    @NotNull(groups = FindEducationResource.class)
//    private List<Integer> indexIds;
//
//    @NotNull(groups = FindEducationResource.class)
//    private List<Integer> years;
//
//    public interface FindEducationResource {};
}
