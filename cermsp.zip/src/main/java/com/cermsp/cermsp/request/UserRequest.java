package com.cermsp.cermsp.request;

import com.cermsp.cermsp.repository.UserRepository;
import com.cermsp.cermsp.request.validator.Unique;
import lombok.Data;
import org.hibernate.validator.constraints.Length;

import javax.validation.constraints.NotNull;

/**
 * 封装（承载）请求参数
 */
@Data
public class UserRequest {

    private Integer id;
    @NotNull(groups = {Register.class, Login.class})
    @Length(min = 1, max = 30, groups = {Register.class, Login.class})
    @Unique(repository = UserRepository.class, field = "username", groups = Register.class)
    private String username;
    @NotNull(groups = {Register.class, Login.class})
    @Length(min = 6, max = 50, groups = {Register.class, Login.class})
    private String password;
    @NotNull(groups = Register.class)
    @Length(min = 11, max = 11, groups = Register.class)
    @Unique(repository = UserRepository.class, field = "telephone", groups = Register.class)
    private String telephone;

    public interface Register {
    }

    public interface Login {
    }
}
