package com.cermsp.cermsp.request;

import lombok.Data;

@Data
public class RegionalismRequest {

    private Integer childrenLevel = 0;
    private String name = "";

    public interface findRegionalism {
    }

    public interface findRegionalismBySearch {
    }

    public interface findRegionalismWithEducationResource {
    }
}
