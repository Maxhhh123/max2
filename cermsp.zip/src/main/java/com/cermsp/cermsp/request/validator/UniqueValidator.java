package com.cermsp.cermsp.request.validator;

import com.cermsp.cermsp.repository.BaseRepository;
import com.cermsp.cermsp.util.SpringContextUtil;
import org.springframework.context.ApplicationContext;
import org.springframework.stereotype.Component;

import javax.validation.ConstraintValidator;
import javax.validation.ConstraintValidatorContext;

@Component
public class UniqueValidator implements ConstraintValidator<Unique, Object> {
    private String field;
    private Class<? extends BaseRepository<?>> repository;

    @Override
    public void initialize(Unique constraintAnnotation) {
        ConstraintValidator.super.initialize(constraintAnnotation);
        this.repository = constraintAnnotation.repository();
        this.field = constraintAnnotation.field();
    }

    @Override
    public boolean isValid(Object value, ConstraintValidatorContext constraintValidatorContext) {
        ApplicationContext context = SpringContextUtil.getApplicationContext();
        BaseRepository<?> repository = context.getBean(this.repository);
        return repository.isUnique(field, value);
    }
}
