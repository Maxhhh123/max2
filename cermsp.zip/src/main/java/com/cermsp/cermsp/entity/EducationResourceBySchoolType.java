package com.cermsp.cermsp.entity;

import com.baomidou.mybatisplus.annotation.EnumValue;
import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableId;
import lombok.Data;
import lombok.EqualsAndHashCode;

@Data
@EqualsAndHashCode(callSuper = false)
public class EducationResourceBySchoolType implements Entity {
    @TableId(type = IdType.AUTO)
    private Integer id;
    private SchoolTypeEnum schoolType;
    private Integer schoolCount;
    private Integer teacherCount;
    private Integer studentCount;
    private Float educatedPopulationPercentage;
    private Integer regionalismId;

    public Integer getSchoolType() {
        return schoolType.value;
    }

    public SchoolTypeEnum getSchoolTypeEnum() {
        return schoolType;
    }

    public enum SchoolTypeEnum {
        ILLITERACY(0, "未上学", 0),
        PRIMARY_SCHOOL(1, "小学", 6),
        JUNIOR_HIGH_SCHOOL(2, "普通初中", 9),
        SENIOR_HIGH_SCHOOL(3, "普通高中", 12),
        UNIVERSITY(4, "普通本专科", 16);

        @EnumValue
        private final Integer value;
        private final Integer year;

        SchoolTypeEnum(Integer value, String name, Integer year) {
            this.value = value;
            this.year = year;
        }

        public Integer getYear() {
            return year;
        }
    }
}
