package com.cermsp.cermsp.entity;

import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableId;
import com.cermsp.cermsp.pojo.bo.FindEducationResourceBo;
import com.fasterxml.jackson.annotation.JsonView;
import lombok.Data;
import lombok.EqualsAndHashCode;

@Data
@EqualsAndHashCode(callSuper = false)
public class Index implements Entity {
    @JsonView({
            View.FindIndex.class,
            FindEducationResourceBo.View.FindEducationResource.class
    })
    @TableId(type = IdType.AUTO)
    private Integer id;
    @JsonView({View.FindIndex.class, FindEducationResourceBo.View.FindEducationResource.class})
    private String name;
    @JsonView({FindEducationResourceBo.View.FindEducationResource.class})
    private String columnName;
    @JsonView({View.FindIndex.class})
    private String url;
    @JsonView({FindEducationResourceBo.View.FindEducationResource.class})
    private String unit;
    private Integer parentId;

    public static class View {
        public interface FindIndex {
        }
    }
}
