package com.cermsp.cermsp.entity;

public interface Entity {
}
