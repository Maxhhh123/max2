package com.cermsp.cermsp.entity;

import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableId;
import com.fasterxml.jackson.annotation.JsonView;
import lombok.Data;
import lombok.EqualsAndHashCode;

@Data
@EqualsAndHashCode(callSuper = false)
public class EducationResource implements Entity {
    @TableId(type = IdType.AUTO)
    private Integer id;
    @JsonView(Regionalism.View.Resource.class)
    private Integer examineeCount;
    @JsonView(Regionalism.View.Resource.class)
    private Integer enrollmentCount;
    @JsonView(Regionalism.View.Resource.class)
    private Float population;
    @JsonView(Regionalism.View.Resource.class)
    private Float gdp;
    @JsonView(Regionalism.View.Resource.class)
    private Float educationalFund;
    private Integer regionalismId;
}
