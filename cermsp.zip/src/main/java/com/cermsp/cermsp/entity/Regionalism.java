package com.cermsp.cermsp.entity;

import com.baomidou.mybatisplus.annotation.EnumValue;
import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableField;
import com.baomidou.mybatisplus.annotation.TableId;
import com.fasterxml.jackson.annotation.JsonView;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import lombok.Data;
import lombok.EqualsAndHashCode;

import java.util.ArrayList;
import java.util.List;

@Data
@EqualsAndHashCode(callSuper = false)
public class Regionalism implements Entity {
    @JsonView(View.Base.class)
    @TableId(type = IdType.AUTO)
    private Integer id;
    @JsonView(View.Base.class)
    private String name;
    @JsonView(View.Base.class)
    private Integer regionCode;
    @JsonView(View.Base.class)
    private LevelEnum level;
    private Float lng;
    private Float lat;
    @JsonView(View.Children.class)
    private Integer parentId;
    private Double area;
    //    @TableField(typeHandler = MultiPointTypeHandler.class)
//    @TableField(typeHandler = JacksonTypeHandler.class)
    @JsonView(View.Geometry.class)
    private JsonNode geometry;
    @JsonView(View.Children.class)
    private Integer year;
    @JsonView(View.Children.class)
    @TableField(exist = false)
    private List<Regionalism> children;
    @JsonView(View.Resource.class)
    @TableField(exist = false)
    private EducationResource educationResource;

    public Integer getLevel() {
        return level.value;
    }

    public void addChild(Regionalism regionalism) {
        if (children == null) children = new ArrayList<>();
        children.add(regionalism);
    }

    public enum LevelEnum {
        COUNTRY(0, "国家"),
        PROVINCE(1, "一级行政区"),
        CITY(2, "二级行政区"),
        DISTRICT(3, "三级行政区"),
        STREET(4, "四级行政区");

        @EnumValue
        private final Integer value;
        private final String name;

        LevelEnum(Integer level, String name) {
            this.value = level;
            this.name = name;
        }
    }

    public void setGeometry(String geometry) throws JsonProcessingException {
        this.geometry  = new ObjectMapper().readTree(geometry);
    }

    public static class View {
        public interface Base {
        }

        public interface Resource {
        }

        public interface Geometry {
        }

        public interface Children {
        }

        public interface FindRegionalismById extends Base, Geometry, Resource, Children {
        }

        public interface FindRegionalismWithEducationResource extends Base, Resource, Children {
        }

        public interface FindRegionalismBySearch extends Base {
        }

        public interface GetGiniCoefficient extends Base, Geometry, Children {
        }
    }
}
