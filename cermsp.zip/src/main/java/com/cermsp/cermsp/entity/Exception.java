package com.cermsp.cermsp.entity;

public class Exception implements Entity {
}
