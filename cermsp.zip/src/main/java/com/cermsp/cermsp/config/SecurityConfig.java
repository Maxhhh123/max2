package com.cermsp.cermsp.config;

import com.cermsp.cermsp.config.properties.AuthenticationUrlProperties;
import com.cermsp.cermsp.config.properties.JwtProperties;
import com.cermsp.cermsp.entity.User;
import com.cermsp.cermsp.exception.security.CustomAuthenticationEntryPoint;
import com.cermsp.cermsp.filter.AccessTokenAuthenticationFilter;
import com.cermsp.cermsp.filter.ExceptionHandlerFilter;
import com.cermsp.cermsp.filter.LoginFilter;
import com.cermsp.cermsp.resource.UserResource;
import com.cermsp.cermsp.util.JwtUtil;
import com.cermsp.cermsp.util.ResponseUtil;
import org.springframework.boot.autoconfigure.condition.ConditionalOnClass;
import org.springframework.boot.autoconfigure.security.SecurityProperties;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.core.annotation.Order;
import org.springframework.http.HttpMethod;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.configuration.WebSecurityConfigurerAdapter;
import org.springframework.security.config.http.SessionCreationPolicy;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.security.web.authentication.AuthenticationSuccessHandler;
import org.springframework.security.web.authentication.UsernamePasswordAuthenticationFilter;
import org.springframework.security.web.authentication.logout.LogoutFilter;
import org.springframework.security.web.util.matcher.AntPathRequestMatcher;
import org.springframework.web.cors.CorsConfiguration;
import org.springframework.web.cors.CorsConfigurationSource;
import org.springframework.web.cors.CorsUtils;
import org.springframework.web.cors.UrlBasedCorsConfigurationSource;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

@Configuration
@ConditionalOnClass(WebSecurityConfigurerAdapter.class)
public class SecurityConfig {

    private static final String LOGIN_PROCESSING_URL = "/api/v1/authentication";

    @Configuration
    @Order(SecurityProperties.BASIC_AUTH_ORDER)
    static class DefaultConfigurerAdapter extends WebSecurityConfigurerAdapter {

        private final JwtProperties jwtProperties;

        private final AuthenticationUrlProperties authenticationUrlProperties;

        private final AccessTokenAuthenticationFilter accessTokenAuthenticationFilter;

        private final CustomAuthenticationEntryPoint customAuthenticationEntryPoint;

        private final ExceptionHandlerFilter exceptionHandlerFilter;

        public DefaultConfigurerAdapter(JwtProperties jwtProperties, AuthenticationUrlProperties authenticationUrlProperties, AccessTokenAuthenticationFilter accessTokenAuthenticationFilter, CustomAuthenticationEntryPoint customAuthenticationEntryPoint, ExceptionHandlerFilter exceptionHandlerFilter) {
            this.jwtProperties = jwtProperties;
            this.authenticationUrlProperties = authenticationUrlProperties;
            this.accessTokenAuthenticationFilter = accessTokenAuthenticationFilter;
            this.customAuthenticationEntryPoint = customAuthenticationEntryPoint;
            this.exceptionHandlerFilter = exceptionHandlerFilter;
        }

        @Override
        protected void configure(HttpSecurity http) throws Exception {
            http
                    .exceptionHandling()
                    // 当用户无权访问资源时发送 401 响应
                    .authenticationEntryPoint(customAuthenticationEntryPoint)
                    // 当用户访问资源因权限不足时发送 403 响应
//                .accessDeniedHandler(securityProblemSupport)
                    .and()
//                    .headers().frameOptions().disable()
                    .logout().logoutUrl("/auth/logout")
                    .and()
                    // 不需要 session（不创建会话）
                    .sessionManagement().sessionCreationPolicy(SessionCreationPolicy.STATELESS)
                    .and()
                    .formLogin().permitAll()
                    .and()
                    // 添加自定义过滤器到过滤器链
                    .addFilterAt(loginFilterBean(), UsernamePasswordAuthenticationFilter.class)
                    .addFilterBefore(accessTokenAuthenticationFilter, UsernamePasswordAuthenticationFilter.class)
                    .addFilterBefore(exceptionHandlerFilter, LogoutFilter.class);
//                .apply(securityConfigurationAdapter());
            http.cors().and().csrf().disable();

            // 添加需要验证的路由
            for (AuthenticationUrlProperties.AuthenticationUrl url : authenticationUrlProperties.getAuthenticationUrls()) {
                http.authorizeRequests().antMatchers(url.getMethod(), url.getUrl()).authenticated();
            }
            http.authorizeRequests().anyRequest().permitAll();
        }

        @Bean
        @Override
        public AuthenticationManager authenticationManagerBean() throws Exception {
            return super.authenticationManagerBean();
        }

        @Bean
        public LoginFilter loginFilterBean() throws Exception {
            LoginFilter filter = new LoginFilter();
            filter.setAuthenticationManager(authenticationManagerBean());
            filter.setRequiresAuthenticationRequestMatcher(new AntPathRequestMatcher(LOGIN_PROCESSING_URL, "POST"));
            filter.setAuthenticationSuccessHandler(authenticationSuccessHandler());
            return filter;
        }

        /*
         * 注入BCryptPasswordEncoder
         */
        @Bean
        public BCryptPasswordEncoder bCryptPasswordEncoder() {
            return new BCryptPasswordEncoder();
        }

        @Bean
        public AuthenticationSuccessHandler authenticationSuccessHandler() {
            return (request, response, authentication) -> {
                Map<String, Object> map = new HashMap<>();

                User user = (User) authentication.getPrincipal();

                JwtUtil jwtUtil = new JwtUtil(jwtProperties);

                map.put("access_token", jwtUtil.createAccessToken(user.getUsername()));
                map.put("refresh_token", jwtUtil.createRefreshToken(user.getUsername()));
                Map<String, Object> resource = new UserResource().addToData(map).toResponse();

                ResponseUtil.setJsonBody(response, resource);
            };
        }

        @Bean
        CorsConfigurationSource corsConfigurationSource() {
            CorsConfiguration configuration = new CorsConfiguration();
            configuration.setAllowedOrigins(List.of("*"));
            configuration.setAllowedMethods(List.of("*"));
            UrlBasedCorsConfigurationSource source = new UrlBasedCorsConfigurationSource();
            source.registerCorsConfiguration("/**", configuration);
            return source;
        }
    }
}
