package com.cermsp.cermsp.config.properties;

import lombok.Data;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.stereotype.Component;

@Data
@Component
@ConfigurationProperties(prefix = "jwt")
public class JwtProperties {
    // 签名密钥
    private String secret;
    // 有效期
    private long expireTime;
    // 刷新时间
    private long refreshTime;
}
