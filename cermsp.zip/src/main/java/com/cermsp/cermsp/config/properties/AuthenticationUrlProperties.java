package com.cermsp.cermsp.config.properties;

import lombok.Data;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.http.HttpMethod;
import org.springframework.stereotype.Component;

import java.util.List;

@Data
@Component
@ConfigurationProperties(prefix = "authentication")
public class AuthenticationUrlProperties {

    private List<AuthenticationUrl> authenticationUrls;

    @Data
    public static class AuthenticationUrl {
        private String url;
        private HttpMethod method;

        public void setMethod(String method) {
            this.method = HttpMethod.resolve(method);
        }
    }
}
