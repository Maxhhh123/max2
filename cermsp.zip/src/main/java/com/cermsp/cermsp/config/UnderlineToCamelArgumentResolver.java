package com.cermsp.cermsp.config;

import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.BeanWrapper;
import org.springframework.beans.BeansException;
import org.springframework.beans.PropertyAccessorFactory;
import org.springframework.core.MethodParameter;
import org.springframework.lang.NonNull;
import org.springframework.web.bind.support.WebDataBinderFactory;
import org.springframework.web.context.request.NativeWebRequest;
import org.springframework.web.method.support.HandlerMethodArgumentResolver;
import org.springframework.web.method.support.ModelAndViewContainer;

import java.util.Iterator;
import java.util.Objects;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

@Slf4j
public class UnderlineToCamelArgumentResolver implements HandlerMethodArgumentResolver {

    /**
     * 匹配下划线的格式
     */
    private static final Pattern pattern = Pattern.compile("_(\\w)");

    private static String underLineToCamel(String source) {
        Matcher matcher = pattern.matcher(source);
        StringBuilder sb = new StringBuilder();
        while (matcher.find()) {
            matcher.appendReplacement(sb, matcher.group(1).toUpperCase());
        }
        matcher.appendTail(sb);
        return sb.toString();
    }

    @Override
    public boolean supportsParameter(@NonNull MethodParameter methodParameter) {
        // return methodParameter.hasParameterAnnotation(ParamModel.class);
        // 全局使用的话，直接返回true
        return true;
    }

    @Override
    public Object resolveArgument(@NonNull MethodParameter parameter, ModelAndViewContainer container, @NonNull NativeWebRequest webRequest, WebDataBinderFactory binderFactory) {
        Object obj = null;
        try {
            obj = parameter.getParameterType().getDeclaredConstructor().newInstance();
        } catch (Exception e) {
            log.error("无法实例化的数据类型：{}", parameter.getParameterType());
//            throw new ParamException(PARAM_RESOLVE_ERR);
        }
        BeanWrapper wrapper = PropertyAccessorFactory.forBeanPropertyAccess(Objects.requireNonNull(obj));
        Iterator<String> paramNames = webRequest.getParameterNames();
        while (paramNames.hasNext()) {
            String paramName = paramNames.next();
            Object o = webRequest.getParameter(paramName);
            try {
                wrapper.setPropertyValue(underLineToCamel(paramName), o);
            } catch (BeansException e) {
                log.info("下划线转驼峰时出错，实体类 {} 中无对应属性：{}", Objects.requireNonNull(o).getClass().getName(), paramName);
            }
        }
        return obj;
    }
}
