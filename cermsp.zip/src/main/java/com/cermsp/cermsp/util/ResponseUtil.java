package com.cermsp.cermsp.util;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.SerializationFeature;

import javax.servlet.ServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.HashMap;
import java.util.Map;
import java.util.stream.Collectors;

public class ResponseUtil {
    public static Map<?, ?> getJsonBody(ServletRequest servletRequest) {
        try {
            String body = servletRequest.getReader().lines().collect(Collectors.joining(System.lineSeparator()));
            return new ObjectMapper().readValue(body, HashMap.class);
        } catch (IOException e) {
            throw new RuntimeException(e);
        }
    }

    public static void setJsonBody(HttpServletResponse response, Map<String, Object> resource) {
        response.setCharacterEncoding("utf-8");
        response.setHeader("Content-Type", "application/json");
        PrintWriter writer;
        ObjectMapper mapper = new ObjectMapper().configure(SerializationFeature.FAIL_ON_EMPTY_BEANS, false);
        try {
            writer = response.getWriter();
            writer.print(mapper.writeValueAsString(resource));
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
        writer.flush();
        writer.close();
    }
}