package com.cermsp.cermsp.util.enumation;

/**
 * LoginTypeEnum
 *
 * @author Felordcn
 * @since 16 :23 2019/10/17
 */
public enum LoginTypeEnum {

    /**
     * Json 提交.
     */
    JSON,

    /**
     * 验证码.
     */
    CAPTCHA

}
