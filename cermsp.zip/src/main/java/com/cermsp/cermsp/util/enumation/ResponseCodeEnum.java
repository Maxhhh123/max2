package com.cermsp.cermsp.util.enumation;

import lombok.Getter;

@Getter
public enum ResponseCodeEnum {
    SUCCESS(200, "成功"),//成功
    BAD_REQUEST(400, "Bad Request"),
    BAD_REQUEST_BIND_EXCEPTION(4001, "参数错误"),
    BAD_REQUEST_USERNAME_REPEAT(4002, "用户名已存在"),
    BAD_REQUEST_TELEPHONE_REPEAT(4003, "该手机号已注册"),

    // 认证类异常
    UNAUTHORIZED(401, "认证失败"),
    UNAUTHORIZED_MALFORMED_JWT(4011, "token 格式错误"),
    UNAUTHORIZED_ACCESS_TOKEN_EXPIRED(4012, "accessToken 过期"),
    UNAUTHORIZED_REFRESH_TOKEN_EXPIRED(4013, "refreshToken 过期"),
    UNAUTHORIZED_USERNAME_NOT_FOUND(4014, "用户不存在"),
    UNAUTHORIZED_BAD_CREDENTIALS(4015, "用户名或密码错误"),

    // 授权类异常
    FORBIDDEN(403, "无权限访问"),
    NOT_FOUND(404, "接口不存在"),//接口不存在
    METHOD_NOT_ALLOWED(405, "方法不被允许"),
    INTERNAL_SERVER_ERROR(500, "系统繁忙"),//服务器内部错误

    /*参数错误:1001-1999*/
    PARAMS_IS_INVALID(1001, "参数无效"),
    PARAMS_IS_BLANK(1002, "参数为空");
    /*用户错误2001-2999*/

    private final Integer code;
    private final String message;

    ResponseCodeEnum(int code, String message) {
        this.code = code;
        this.message = message;
    }
}
