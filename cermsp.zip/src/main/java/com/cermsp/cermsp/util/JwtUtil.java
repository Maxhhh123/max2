package com.cermsp.cermsp.util;

import com.cermsp.cermsp.config.properties.JwtProperties;
import com.cermsp.cermsp.exception.AccessTokenExpiredException;
import com.cermsp.cermsp.exception.RefreshTokenExpiredException;
import io.jsonwebtoken.*;
import io.jsonwebtoken.security.Keys;
import org.springframework.boot.context.properties.EnableConfigurationProperties;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.Authentication;

import javax.crypto.SecretKey;
import javax.servlet.http.HttpServletRequest;
import java.nio.charset.StandardCharsets;
import java.util.Date;

@EnableConfigurationProperties(JwtProperties.class)
public class JwtUtil {

    private final JwtParser parser;
    private final JwtProperties properties;

    public JwtUtil(JwtProperties properties) {
        this.properties = properties;
        parser = Jwts.parserBuilder().setSigningKey(getKey()).build();
    }

    public String createAccessToken(String username) {
        Claims claims = Jwts.claims();
        claims.put("type", TokenType.ACCESS.name());
        Date now = new Date();
        Date validity = new Date(now.getTime() + properties.getExpireTime() * 1000 * 60);

        return Jwts.builder()
                .setClaims(claims)
                .setIssuedAt(now)
                .setExpiration(validity)
                .setSubject(username)
                .signWith(getKey())
                .compact();
    }

    public String createRefreshToken(String username) {
        Claims claims = Jwts.claims();
        claims.put("type", TokenType.REFRESH.name());
        Date now = new Date();
        Date validity = new Date(now.getTime() + properties.getRefreshTime() * 1000 * 60);

        return Jwts.builder()
                .setClaims(claims)
                .setIssuedAt(now)
                .setExpiration(validity)
                .setSubject(username)
                .signWith(getKey())
                .compact();
    }

    public String refreshAccessToken(String refreshToken) {
        validateRefreshToken(refreshToken);
        String username = getUsername(refreshToken);
        return createAccessToken(username);
    }

    public Claims getTokenBody(String token) {
        return parser.parseClaimsJws(token).getBody();
    }

    public SecretKey getKey() {
        return Keys.hmacShaKeyFor(properties.getSecret().getBytes(StandardCharsets.UTF_8));
    }

    public String getUsername(String token) {
        return getTokenBody(token).getSubject();
    }

    public String getUsername(HttpServletRequest request) {
        String token = resolveToken(request);
        return getUsername(token);
    }

    public void validateAccessToken(String token) {
        try {
            Jws<Claims> claims = parser.parseClaimsJws(token);
            TokenType type = TokenType.valueOf(claims.getBody().get("type", String.class));
            if (type != TokenType.ACCESS) {
                throw new MalformedJwtException(null);
            }
        } catch (JwtException | IllegalArgumentException e) {
            throw new AccessTokenExpiredException();
        }
    }

    public Boolean hasToken(HttpServletRequest request) {
        String bearerToken = request.getHeader("Authorization");
        return bearerToken != null && bearerToken.startsWith("Bearer ");
    }

    public String resolveToken(HttpServletRequest request) {
        String bearerToken = request.getHeader("Authorization");
        if (bearerToken != null && bearerToken.startsWith("Bearer ")) {
            return bearerToken.substring(7);
        } else {
            throw new MalformedJwtException(null);
        }
    }

    public void validateRefreshToken(String token) {
        try {
            Jws<Claims> claims = parser.parseClaimsJws(token);
            TokenType type = TokenType.valueOf(claims.getBody().get("type", String.class));
            if (type != TokenType.REFRESH) {
                throw new MalformedJwtException(null);
            }
        } catch (JwtException | IllegalArgumentException e) {
            throw new RefreshTokenExpiredException();
        }
    }

    public TokenType getTokenType(String token) {
        try {
            Jws<Claims> claims = parser.parseClaimsJws(token);
            return TokenType.valueOf(claims.getBody().get("type", String.class));
        } catch (Exception e) {
            return null;
        }
    }

    public Authentication getAuthentication(String token) {
        Claims claims = getTokenBody(token);
        String username = claims.getSubject();
        return new UsernamePasswordAuthenticationToken(username, token);
    }

    public enum TokenType {
        ACCESS,
        REFRESH
    }
}
