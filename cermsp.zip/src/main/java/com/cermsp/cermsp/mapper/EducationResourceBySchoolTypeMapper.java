package com.cermsp.cermsp.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.cermsp.cermsp.entity.EducationResourceBySchoolType;
import org.apache.ibatis.annotations.Mapper;

@Mapper
public interface EducationResourceBySchoolTypeMapper extends BaseMapper<EducationResourceBySchoolType> {
}
