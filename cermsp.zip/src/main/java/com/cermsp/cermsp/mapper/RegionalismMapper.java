package com.cermsp.cermsp.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.cermsp.cermsp.entity.Index;
import com.cermsp.cermsp.entity.Regionalism;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;

import java.util.List;

@Mapper
public interface RegionalismMapper extends BaseMapper<Regionalism> {

    //    @MapKey("id")
    List<Regionalism> selectChildrenById(@Param("id") Integer id, @Param("childrenLevel") Integer childrenLevel);

    List<Regionalism> findRegionalismWithEducationResource(Integer regionCode, Integer childrenLevel);

    List<Regionalism> findRegionalismBySearch(String name);

    List<Regionalism> listRegionalismsByCodesWithEducationResource(List<Index> indexes, List<Integer> regionCodes, List<Integer> years, Integer childrenLevel);
}
