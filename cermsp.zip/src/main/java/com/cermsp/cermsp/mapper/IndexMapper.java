package com.cermsp.cermsp.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.cermsp.cermsp.entity.Index;
import org.apache.ibatis.annotations.Mapper;

@Mapper
public interface IndexMapper extends BaseMapper<Index> {
}
