package com.cermsp.cermsp.repository;

import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.cermsp.cermsp.entity.Entity;

public class BaseRepository<T extends Entity> {

    protected BaseMapper<T> mapper;

    public Boolean isUnique(String column, Object value) {
        QueryWrapper<T> wrapper = new QueryWrapper<>();
        Long count = mapper.selectCount(wrapper.eq(column, value));
        return count == 0;
    }
}
