package com.cermsp.cermsp.repository;

import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.cermsp.cermsp.entity.Index;
import com.cermsp.cermsp.mapper.IndexMapper;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public class IndexRepository {

    private final IndexMapper mapper;

    public IndexRepository(IndexMapper mapper) {
        this.mapper = mapper;
    }

    public List<Index> findIndexParent() {
        return mapper.selectList(new QueryWrapper<Index>().isNull("parent_id"));
    }

    public List<Index> findIndex(Integer parentId) {
        return mapper.selectList(new QueryWrapper<Index>().eq("parent_id", parentId));
    }

    public List<Index> listIndexes(List<Integer> indexIds) {
        return mapper.selectBatchIds(indexIds);
    }
}
