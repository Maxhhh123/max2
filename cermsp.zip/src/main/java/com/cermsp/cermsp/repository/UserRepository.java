package com.cermsp.cermsp.repository;

import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.cermsp.cermsp.entity.User;
import org.springframework.stereotype.Repository;

@Repository
public class UserRepository extends BaseRepository<User> {

    public UserRepository(BaseMapper<User> mapper) {
        super.mapper = mapper;
    }

    public void insert(User user) {
        mapper.insert(user);
    }

    public User selectByUsername(String username) {
        return mapper.selectOne(new QueryWrapper<User>().eq("username", username));
    }
}
