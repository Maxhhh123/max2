package com.cermsp.cermsp.repository;

import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.cermsp.cermsp.entity.EducationResourceBySchoolType;
import com.cermsp.cermsp.mapper.EducationResourceBySchoolTypeMapper;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public class EducationResourceBySchoolTypeRepository {

    private final EducationResourceBySchoolTypeMapper mapper;

    public EducationResourceBySchoolTypeRepository(EducationResourceBySchoolTypeMapper mapper) {
        this.mapper = mapper;
    }

    public List<EducationResourceBySchoolType> findStudentCountByIds(List<Integer> regionalismIds) {
        return mapper.selectList(
                new QueryWrapper<EducationResourceBySchoolType>().in("regionalism_id", regionalismIds)
                        .orderByAsc("regionalism_id", "school_type"));
    }
}
