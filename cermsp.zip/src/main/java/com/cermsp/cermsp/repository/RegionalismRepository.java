package com.cermsp.cermsp.repository;

import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.cermsp.cermsp.entity.Index;
import com.cermsp.cermsp.entity.Regionalism;
import com.cermsp.cermsp.mapper.RegionalismMapper;
import org.springframework.stereotype.Repository;

import java.util.*;

@Repository
public class RegionalismRepository extends BaseRepository<Regionalism> {

    private final RegionalismMapper mapper;

    public RegionalismRepository(RegionalismMapper mapper) {
        this.mapper = mapper;
    }

    public Regionalism findRegionalismById(Integer id, Integer childrenLevel) {
        List<Regionalism> regionalisms = mapper.selectChildrenById(id, childrenLevel);
        return list2Tree(regionalisms, id);
    }

    public List<Regionalism> findRegionalismWithEducationResource(Integer regionCode, Integer childrenLevel) {
        List<Regionalism> regionalisms = mapper.findRegionalismWithEducationResource(regionCode, childrenLevel);
        return list2Tree(regionalisms, Collections.singletonList(regionCode));
    }

    public List<Regionalism> listRegionalismByCodeWithEducationResource(List<Index> indexes, List<Integer> regionCodes, List<Integer> years, Integer childrenLevel) {
        return list2Tree(mapper.listRegionalismsByCodesWithEducationResource(indexes, regionCodes, years, childrenLevel), regionCodes);
    }

    /**
     * 将数据库返回的 列表形式 按照父子关系转换为 嵌套形式
     *
     * @param regionalisms 列表形式
     * @param regionCodes  要返回的嵌套顶级项 regionCode（其他项都作为这些顶级项的子项返回）
     * @return 嵌套形式
     */
    private List<Regionalism> list2Tree(List<Regionalism> regionalisms, List<Integer> regionCodes) {

        LinkedHashMap<Integer, Regionalism> regionalismMap = appendChildren(regionalisms);
        Set<Integer> regionCodeSet = new HashSet<>(regionCodes);

        // 返回需要查询的地区
        List<Regionalism> regionalismsWithChildren = new ArrayList<>();
        for (Regionalism regionalism : regionalismMap.values()) {
            if (regionCodeSet.contains(regionalism.getRegionCode())) regionalismsWithChildren.add(regionalism);
        }

        return regionalismsWithChildren;
    }

    /**
     * 将数据库返回的 列表形式 按照父子关系转换为 嵌套形式
     *
     * @param regionalisms 列表形式
     * @param id           要返回的嵌套顶级项 id（其他项都作为这些顶级项的子项返回）
     * @return 嵌套形式
     */
    private Regionalism list2Tree(List<Regionalism> regionalisms, Integer id) {
        LinkedHashMap<Integer, Regionalism> regionalismMap = appendChildren(regionalisms);
        return regionalismMap.get(id);
    }

    /**
     * 将子级行政区添加到父级里，形成树形关系
     *
     * @param regionalisms 列表形式
     * @return 嵌套形式
     */
    private LinkedHashMap<Integer, Regionalism> appendChildren(List<Regionalism> regionalisms) {
        LinkedHashMap<Integer, Regionalism> regionalismMap = new LinkedHashMap<>();

        for (Regionalism regionalism : regionalisms) {
            regionalismMap.put(regionalism.getId(), regionalism);
        }

        regionalismMap.forEach((Integer id, Regionalism children) -> {
            Regionalism parent = regionalismMap.get(children.getParentId());
            if (parent != null) {
                parent.addChild(children);
            }
        });
        return regionalismMap;
    }

    public List<Regionalism> findRegionalismBySearch(String name) {
        return mapper.findRegionalismBySearch(name);
    }

    public List<Integer> findAllYears() {
        List<Regionalism> regionalisms = mapper.selectList(new QueryWrapper<Regionalism>().select("DISTINCT year").orderByAsc("year"));
        ArrayList<Integer> years = new ArrayList<>();
        for (Regionalism regionalism : regionalisms) {
            years.add(regionalism.getYear());
        }
        return years;
    }
}
