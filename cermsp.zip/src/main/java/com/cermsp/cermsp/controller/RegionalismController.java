package com.cermsp.cermsp.controller;

import com.cermsp.cermsp.entity.Regionalism;
import com.cermsp.cermsp.pojo.bo.FindEducationResourceBo;
import com.cermsp.cermsp.request.RegionalismRequest;
import com.cermsp.cermsp.resource.JsonResource;
import com.cermsp.cermsp.resource.RegionalismResource;
import com.cermsp.cermsp.service.RegionalismService;
import com.fasterxml.jackson.annotation.JsonView;
import org.springframework.util.CollectionUtils;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.*;

import javax.validation.constraints.NotNull;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@RestController
@RequestMapping("${route.prefix-api-v1}")
public class RegionalismController {

    private final RegionalismService service;

    public RegionalismController(RegionalismService service) {
        this.service = service;
    }


    @JsonView(Regionalism.View.FindRegionalismById.class)
    @GetMapping("regionalism/{regionalism_id}")
    public Map<String, Object> findRegionalismById(
            @Validated(RegionalismRequest.findRegionalism.class) RegionalismRequest request,
            @PathVariable("regionalism_id") Integer regionalismId) {
        Regionalism regionalism = service.findRegionalismById(request, regionalismId);
        return new RegionalismResource(regionalism).toResponse();
    }

    @JsonView(Regionalism.View.FindRegionalismWithEducationResource.class)
    @GetMapping("regionalism/{region_code}/education_resource")
    public Map<String, Object> findRegionalismWithEducationResource (
            @Validated(RegionalismRequest.findRegionalismWithEducationResource.class) RegionalismRequest request,
            @PathVariable("region_code") Integer regionCode) {
        List<Regionalism> regionalisms = service.findRegionalismWithEducationResource(request, regionCode);
        return new RegionalismResource(regionalisms).toResponse();
    }

    @JsonView(Regionalism.View.FindRegionalismBySearch.class)
    @GetMapping("regionalism/search")
    public Map<String, Object> findRegionalismBySearch(
            @Validated(RegionalismRequest.findRegionalismBySearch.class) RegionalismRequest request) {
        List<Regionalism> regionalisms = service.findRegionalismBySearch(request);
        return new RegionalismResource(regionalisms).toResponse();
    }

    @GetMapping("regionalism/year")
    public Map<String, Object> findAllYears() {
        List<Integer> years = service.findAllYears();
        HashMap<String, Object> data = new HashMap<>();
        data.put("years", years);
        return new RegionalismResource().setData(data).toResponse();
    }

    @JsonView(FindEducationResourceBo.View.FindEducationResource.class)
    @GetMapping("education-resource")
    public Map<String, Object> findEducationResource(@RequestParam @NotNull List<Integer> years,
                                                     @RequestParam("children_level") @NotNull Integer childrenLevel,
                                                     @RequestParam("index_ids") @NotNull List<Integer> indexIds,
                                                     @RequestParam("region_codes") @NotNull List<Integer> regionCodes) {
        FindEducationResourceBo bo = service.findEducationResource(regionCodes, indexIds, years, childrenLevel);
        return new JsonResource<>(bo).toResponse();
    }

    @JsonView(Regionalism.View.GetGiniCoefficient.class)
    @GetMapping("regionalism/{regionalism_id}/gini-coefficient")
    public Map<String, Object> getGiniCoefficient(@PathVariable("regionalism_id") Integer regionalismId) {
        Regionalism regionalism = service.findRegionalismById(regionalismId);

        if (regionalism == null || CollectionUtils.isEmpty(regionalism.getChildren()))
            return new JsonResource<>().toResponse();
        List<Integer> regionalismIds = new ArrayList<>();
        regionalismIds.add(regionalism.getId());
        for (Regionalism children : regionalism.getChildren()) {
            regionalismIds.add(children.getId());
        }

        HashMap<String, Object> metadata = new HashMap<>();
        metadata.put("giniCoefficient", service.getGiniCoefficient(regionalismIds));

        return new RegionalismResource(regionalism).setMetadata(metadata).toResponse();
    }
}