package com.cermsp.cermsp.controller;

import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("${route.prefix-api-v1}")
public class EducationResourceBySchoolTypeController {

}
