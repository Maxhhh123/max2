package com.cermsp.cermsp.controller;

import com.cermsp.cermsp.resource.NonEntityResource;
import com.cermsp.cermsp.service.UserService;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.HashMap;
import java.util.Map;

@RestController
@RequestMapping("${route.prefix-api-v1}/authentication")
public class AuthController {

    private final UserService service;

    public AuthController(UserService service) {
        this.service = service;
    }

    @PutMapping()
    public Map<String, Object> refreshJwtToken() {
        String token = service.refreshJwtToken();
        Map<String, Object> data = new HashMap<>();
        data.put("access_token", token);
        return new NonEntityResource().setData(data).toResponse();
    }
}
