package com.cermsp.cermsp.controller;

import com.cermsp.cermsp.entity.Index;
import com.cermsp.cermsp.exception.CustomMethodArgumentNotValidException;
import com.cermsp.cermsp.request.IndexRequest;
import com.cermsp.cermsp.resource.IndexResource;
import com.cermsp.cermsp.service.IndexService;
import com.fasterxml.jackson.annotation.JsonView;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;
import java.util.Map;

@RestController
@RequestMapping("${route.prefix-api-v1}")
public class IndexController {

    private final IndexService service;

    public IndexController(IndexService service) {
        this.service = service;
    }

    @JsonView(Index.View.FindIndex.class)
    @GetMapping("index")
    public Map<String, Object> findIndex(@Validated IndexRequest request) {
        if (request.getIsParent() == 0 && request.getParentId() == null) {
            throw new CustomMethodArgumentNotValidException("parentId 不能为空");
        }
        List<Index> indexes = service.findIndex(request);
        return new IndexResource(indexes).toResponse();
    }
}
