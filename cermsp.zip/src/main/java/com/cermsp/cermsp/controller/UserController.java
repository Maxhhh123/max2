package com.cermsp.cermsp.controller;

import com.cermsp.cermsp.config.properties.JwtProperties;
import com.cermsp.cermsp.entity.User;
import com.cermsp.cermsp.repository.UserRepository;
import com.cermsp.cermsp.request.UserRequest;
import com.cermsp.cermsp.resource.UserResource;
import com.cermsp.cermsp.service.UserService;
import com.fasterxml.jackson.annotation.JsonView;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.*;

import java.util.Map;

@RestController
@RequestMapping("${route.prefix-api-v1}/user")      // RESTful API
public class UserController {

    private final UserService service;

    public UserController(UserService service) {
        this.service = service;
    }   // service 实例化

    @PostMapping()
    public Map<String, Object> register(@Validated(UserRequest.Register.class) @RequestBody UserRequest request) {
        User user = service.register(request);
        return new UserResource(user).toResponse();
    }

    @GetMapping()
    @JsonView(User.View.GetUserByToken.class)
    public Map<String, Object> getUserByToken() {
        User user = (User) SecurityContextHolder.getContext().getAuthentication().getPrincipal();
        return new UserResource(user).toResponse();
    }
}
