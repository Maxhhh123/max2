package com.cermsp.cermsp;

import org.mybatis.spring.annotation.MapperScan;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
@MapperScan("com.cermsp.cermsp.mapper")
public class CermspApplication {

    public static void main(String[] args) {
        SpringApplication.run(CermspApplication.class, args);
    }

}
