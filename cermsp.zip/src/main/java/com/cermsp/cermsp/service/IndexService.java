package com.cermsp.cermsp.service;

import com.cermsp.cermsp.entity.Index;
import com.cermsp.cermsp.repository.IndexRepository;
import com.cermsp.cermsp.request.IndexRequest;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class IndexService {

    private final IndexRepository repository;

    public IndexService(IndexRepository repository) {
        this.repository = repository;
    }

    public List<Index> findIndex(IndexRequest request) {
        if (request.getIsParent() != 0) {
            return repository.findIndexParent();
        } else {
            return repository.findIndex(request.getParentId());
        }
    }
}
