package com.cermsp.cermsp.service;

import com.cermsp.cermsp.config.properties.JwtProperties;
import com.cermsp.cermsp.entity.User;
import com.cermsp.cermsp.repository.UserRepository;
import com.cermsp.cermsp.request.UserRequest;
import com.cermsp.cermsp.util.JwtUtil;
import com.cermsp.cermsp.util.SpringContextUtil;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.stereotype.Service;

import java.util.Date;

@Service
public class UserService implements UserDetailsService {

    private final UserRepository repository;

    private final JwtProperties jwtProperties;

    public UserService(UserRepository repository, JwtProperties jwtProperties) {
        this.repository = repository;
        this.jwtProperties = jwtProperties;
    }

    public User register(UserRequest request) {
        User user = new User();
        user.setUsername(request.getUsername());
        user.setPassword(new BCryptPasswordEncoder().encode(request.getPassword()));
        user.setTelephone(request.getTelephone());
        user.setCreatedAt(new Date());
        repository.insert(user);
        return user;
    }

    @Override
    public UserDetails loadUserByUsername(String username) throws UsernameNotFoundException {
        User user = repository.selectByUsername(username);
        if (user == null) {
            throw new UsernameNotFoundException(null);
        }
        return user;
    }

    public String refreshJwtToken() {
        JwtUtil jwtUtil = new JwtUtil(jwtProperties);
        String freshToken = jwtUtil.resolveToken(SpringContextUtil.getHttpServletRequest());
        return jwtUtil.refreshAccessToken(freshToken);
    }
}
