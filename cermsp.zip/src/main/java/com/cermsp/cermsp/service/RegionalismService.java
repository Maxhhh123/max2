package com.cermsp.cermsp.service;

import com.cermsp.cermsp.entity.EducationResourceBySchoolType;
import com.cermsp.cermsp.entity.Index;
import com.cermsp.cermsp.entity.Regionalism;
import com.cermsp.cermsp.exception.CustomMethodArgumentNotValidException;
import com.cermsp.cermsp.pojo.bo.FindEducationResourceBo;
import com.cermsp.cermsp.repository.EducationResourceBySchoolTypeRepository;
import com.cermsp.cermsp.repository.IndexRepository;
import com.cermsp.cermsp.repository.RegionalismRepository;
import com.cermsp.cermsp.request.RegionalismRequest;
import org.springframework.stereotype.Service;
import org.springframework.util.CollectionUtils;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

@Service
public class RegionalismService {

    private final RegionalismRepository repository;
    private final IndexRepository indexRepository;
    private final EducationResourceBySchoolTypeRepository educationResourceBySchoolTypeRepository;

    public RegionalismService(RegionalismRepository repository, IndexRepository indexRepository,
                              EducationResourceBySchoolTypeRepository educationResourceBySchoolTypeRepository) {
        this.repository = repository;
        this.indexRepository = indexRepository;
        this.educationResourceBySchoolTypeRepository = educationResourceBySchoolTypeRepository;
    }

    public Regionalism findRegionalismById(RegionalismRequest request, Integer regionalismId) {
        return repository.findRegionalismById(regionalismId, request.getChildrenLevel());
    }

    public List<Regionalism> findRegionalismWithEducationResource(RegionalismRequest request, Integer regionCode) {
        return repository.findRegionalismWithEducationResource(regionCode, request.getChildrenLevel());

    }

    public List<Regionalism> findRegionalismBySearch(RegionalismRequest request) {
        return repository.findRegionalismBySearch(request.getName());
    }

    public List<Integer> findAllYears() {
        return repository.findAllYears();
    }

    public FindEducationResourceBo findEducationResource(List<Integer> regionCodes, List<Integer> indexIds, List<Integer> years, Integer childrenLevel) {
        FindEducationResourceBo bo = new FindEducationResourceBo();
        List<Index> indexes = indexRepository.listIndexes(indexIds);

        if (CollectionUtils.isEmpty(indexes)) throw new CustomMethodArgumentNotValidException("指标不存在");
        bo.setIndexes(indexes);

        List<Regionalism> regionalisms = repository.listRegionalismByCodeWithEducationResource(indexes, regionCodes, years, childrenLevel);
        bo.setRegionalisms(regionalisms);

        return bo;
    }

    public Regionalism findRegionalismById(Integer regionalismId) {
        return repository.findRegionalismById(regionalismId, 1);
    }

    public Map<Integer, Float> getGiniCoefficient(List<Integer> regionalismIds) {
        // 计算受教育人口比例
        List<EducationResourceBySchoolType> educationResourceBySchoolTypes = educationResourceBySchoolTypeRepository.findStudentCountByIds(regionalismIds);
        int curId = educationResourceBySchoolTypes.get(0).getRegionalismId();
        float sum = 0;

        Map<Integer, Float> averageEducationalYear = new HashMap<>();
        for (EducationResourceBySchoolType educationResourceBySchoolType : educationResourceBySchoolTypes) {
            if (educationResourceBySchoolType.getRegionalismId() != curId) {
                averageEducationalYear.put(curId, sum);
                curId = educationResourceBySchoolType.getRegionalismId();
                sum = 0;
            }
            sum += educationResourceBySchoolType.getEducatedPopulationPercentage() * educationResourceBySchoolType.getSchoolTypeEnum().getYear();
        }
        averageEducationalYear.put(curId, sum);

        // 计算教育基尼系数
        Map<Integer, Float> giniCoefficient = new HashMap<>();
        sum = 0;
        float preCumulativeYearPercentage = 0;
        for (EducationResourceBySchoolType educationResourceBySchoolType : educationResourceBySchoolTypes) {
            float populationPercentage = educationResourceBySchoolType.getEducatedPopulationPercentage();
            if (educationResourceBySchoolType.getRegionalismId() != curId) {
                giniCoefficient.put(curId, 1 - sum);
                curId = educationResourceBySchoolType.getRegionalismId();
                sum = 0;
                preCumulativeYearPercentage = 0;
            }
            float curCumulativeYearPercentage = populationPercentage
                    * educationResourceBySchoolType.getSchoolTypeEnum().getYear() / averageEducationalYear.get(curId);
            // 占全国人均受教育年限比例
            float cumulativeYearPercentage = preCumulativeYearPercentage * 2 + curCumulativeYearPercentage;
            preCumulativeYearPercentage += curCumulativeYearPercentage;
            sum += populationPercentage * cumulativeYearPercentage;
        }
        giniCoefficient.put(curId, 1 - sum);

        return giniCoefficient;
    }
}
