package com.cermsp.cermsp.pojo.bo;

import com.cermsp.cermsp.entity.Entity;
import com.cermsp.cermsp.entity.Index;
import com.cermsp.cermsp.entity.Regionalism;
import com.fasterxml.jackson.annotation.JsonView;
import lombok.Data;

import java.util.List;

@Data
public class FindEducationResourceBo implements Entity {
    @JsonView(View.FindEducationResource.class)
    private List<Index> indexes;
    @JsonView(View.FindEducationResource.class)
    private List<Regionalism> regionalisms;

    public static class View {
        public interface FindEducationResource extends Regionalism.View.Base, Regionalism.View.Geometry,
                Regionalism.View.Resource, Regionalism.View.Children {
        }
    }
}