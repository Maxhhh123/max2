package com.cermsp.cermsp.resource;

import com.cermsp.cermsp.entity.Entity;

import java.util.Map;

public class NonEntityResource extends JsonResource<Entity> {
}
