package com.cermsp.cermsp.resource;

import com.cermsp.cermsp.entity.Regionalism;
import org.springframework.cglib.beans.BeanMap;
import org.springframework.http.HttpMethod;
import org.springframework.security.web.util.matcher.AntPathRequestMatcher;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class RegionalismResource extends JsonResource<Regionalism> {

    public RegionalismResource() {
    }

    public RegionalismResource(Regionalism entity) {
        super(entity);
    }

    public RegionalismResource(List<Regionalism> entities) {
        super(entities);
    }
}
