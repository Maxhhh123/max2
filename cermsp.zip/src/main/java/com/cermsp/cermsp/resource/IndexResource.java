package com.cermsp.cermsp.resource;

import com.cermsp.cermsp.entity.Index;

import java.util.List;

public class IndexResource extends JsonResource<Index> {
    public IndexResource() {
    }

    public IndexResource(Index entity) {
        super(entity);
    }

    public IndexResource(List<Index> entities) {
        super(entities);
    }
}
