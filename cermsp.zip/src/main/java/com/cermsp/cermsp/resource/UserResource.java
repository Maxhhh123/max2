package com.cermsp.cermsp.resource;

import com.cermsp.cermsp.entity.User;
import org.springframework.http.HttpMethod;
import org.springframework.security.web.util.matcher.AntPathRequestMatcher;

import java.util.HashMap;
import java.util.Map;

public class UserResource extends JsonResource<User> {

    public UserResource(User entity) {
        this.entity = entity;
    }

    public UserResource() {
    }
}
