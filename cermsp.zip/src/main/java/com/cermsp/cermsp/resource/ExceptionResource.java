package com.cermsp.cermsp.resource;

import com.cermsp.cermsp.entity.Exception;
import com.cermsp.cermsp.util.enumation.ResponseCodeEnum;

import java.util.Map;

public class ExceptionResource extends JsonResource<Exception> {

    public ExceptionResource() {
        this.setResponseCode(ResponseCodeEnum.BAD_REQUEST);
    }
}
