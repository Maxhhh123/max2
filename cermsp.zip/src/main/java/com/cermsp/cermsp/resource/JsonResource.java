package com.cermsp.cermsp.resource;

import com.cermsp.cermsp.entity.Entity;
import com.cermsp.cermsp.util.SpringContextUtil;
import com.cermsp.cermsp.util.enumation.ResponseCodeEnum;
import org.springframework.util.CollectionUtils;
import org.springframework.util.StringUtils;

import javax.servlet.http.HttpServletRequest;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Objects;

/**
 * 封装响应的 json
 * @param <T> 实体类
 */
public class JsonResource<T extends Entity> {

    protected ResponseCodeEnum responseCodeEnum;
    protected String message = "";
    protected List<String> messages;
    protected T entity;
    protected List<T> entities;
    protected Map<String, Object> response;
    protected Map<String, Object> metadata;
    protected Map<String, Object> data;
    protected List<Map<String, Object>> collection;
    protected HttpServletRequest request = SpringContextUtil.getHttpServletRequest();

    public JsonResource() {
    }

    public JsonResource(T entity) {
        this.entity = entity;
    }

    public JsonResource(List<T> entities) {
        this.entities = entities;
    }

    public JsonResource<T> setMessages(List<String> messages) {
        this.messages = messages;
        return this;
    }

//    public abstract Map<String, Object> toMap(T entity);

    public JsonResource<T> setResponseCode(ResponseCodeEnum responseCodeEnum) {
        this.responseCodeEnum = responseCodeEnum;
        return this;
    }

    public JsonResource<T> setMessage(String message) {
        this.message = message;
        return this;
    }

    public JsonResource<T> setEntity(T entity) {
        this.entity = entity;
        return this;
    }

    public JsonResource<T> setEntities(List<T> entities) {
        this.entities = entities;
        return this;
    }

    public JsonResource<T> setMetadata(Map<String, Object> metadata) {
        this.metadata = metadata;
        return this;
    }

    public JsonResource<T> setData(Map<String, Object> data) {
        this.data = data;
        return this;
    }

    public JsonResource<T> addToData(String key, Object value) {
        if (data == null) {
            data = new HashMap<>();
        }
        data.put(key, value);
        return this;
    }

    public JsonResource<T> addToData(Map<String, Object> map) {
        if (data == null) {
            data = new HashMap<>();
        }
        data.putAll(map);
        return this;
    }


    public JsonResource<T> addToMetadata(String key, Object value) {
        if (metadata == null) {
            metadata = new HashMap<>();
        }
        metadata.put(key, value);
        return this;
    }

    public Map<String, Object> toResponse() {
        response = new HashMap<>();

        if (responseCodeEnum != null) {
            response.put("status", responseCodeEnum.getCode());
            if (!StringUtils.hasText(message)) {
                message = responseCodeEnum.getMessage();
            }
        } else {
            response.put("status", ResponseCodeEnum.SUCCESS.getCode());
            if (!StringUtils.hasText(message)) {
                message = ResponseCodeEnum.SUCCESS.getMessage();
            }
        }

        if (!CollectionUtils.isEmpty(messages)) {
            response.put("message", messages);
        } else {
            response.put("message", message);
        }

        if (entity != null) {
            response.put("data", entity);
        }
        else if (!CollectionUtils.isEmpty(entities)) {
            response.put("data", entities);
        }
        else response.put("data", Objects.requireNonNullElseGet(data, Object::new));

        if (!CollectionUtils.isEmpty(metadata)) {
            response.put("metadata", metadata);
        }

        return response;
    }
}
